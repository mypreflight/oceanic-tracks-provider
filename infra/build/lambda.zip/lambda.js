"use strict";
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// src/lambda.ts
var lambda_exports = {};
__export(lambda_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(lambda_exports);
var import_node_crypto = require("node:crypto");

// src/application/errors.ts
var ApplicationError = class extends Error {
  static {
    __name(this, "ApplicationError");
  }
  constructor(message) {
    super(message);
    this.name = new.target.name;
  }
};
var TrackSourceUnavailableError = class extends ApplicationError {
  static {
    __name(this, "TrackSourceUnavailableError");
  }
  constructor() {
    super("The track message source is unavailable.");
  }
};
var FixDirectoryUnavailableError = class extends ApplicationError {
  static {
    __name(this, "FixDirectoryUnavailableError");
  }
  constructor() {
    super("The fix directory is unavailable.");
  }
};
var TrackSourceNotConfiguredError = class extends ApplicationError {
  static {
    __name(this, "TrackSourceNotConfiguredError");
  }
  constructor() {
    super("The track message source is not configured.");
  }
};

// src/domain/coordinates.ts
var LAT_LON_POINT = /^(\d{2})(\d{2})?([NS])(\d{3})(\d{2})?([EW])$/;
var NAMED_FIX = /^[A-Z]{2,5}$/;
var AIRWAY = /^[A-Z]{1,3}\d{1,4}[A-Z]?$/;
var EARTH_RADIUS_NM = 3440.065;
function round(value) {
  return Math.round(value * 1e6) / 1e6;
}
__name(round, "round");
function parseLatLonPoint(token) {
  const match = LAT_LON_POINT.exec(token);
  if (!match) {
    return null;
  }
  const [, latDegrees, latMinutes = "0", north, lonDegrees, lonMinutes = "0", east] = match;
  const latitude = (Number(latDegrees) + Number(latMinutes) / 60) * (north === "S" ? -1 : 1);
  const longitude = (Number(lonDegrees) + Number(lonMinutes) / 60) * (east === "W" ? -1 : 1);
  if (Math.abs(latitude) > 90 || Math.abs(longitude) > 180 || Number(latMinutes) >= 60 || Number(lonMinutes) >= 60) {
    return null;
  }
  return { latitude: round(latitude), longitude: round(longitude) };
}
__name(parseLatLonPoint, "parseLatLonPoint");
function classifyToken(token) {
  const coordinates = parseLatLonPoint(token);
  if (coordinates) {
    return { kind: "point", ident: token, coordinates };
  }
  if (NAMED_FIX.test(token)) {
    return { kind: "named", ident: token };
  }
  if (AIRWAY.test(token)) {
    return { kind: "airway", ident: token };
  }
  return { kind: "unknown", ident: token };
}
__name(classifyToken, "classifyToken");
function distanceNm(from, to) {
  const toRadians = /* @__PURE__ */ __name((degrees) => degrees * Math.PI / 180, "toRadians");
  const dLat = toRadians(to.latitude - from.latitude);
  const dLon = toRadians(to.longitude - from.longitude);
  const a = Math.sin(dLat / 2) ** 2 + Math.cos(toRadians(from.latitude)) * Math.cos(toRadians(to.latitude)) * Math.sin(dLon / 2) ** 2;
  return 2 * EARTH_RADIUS_NM * Math.asin(Math.min(1, Math.sqrt(a)));
}
__name(distanceNm, "distanceNm");

// src/domain/place-fixes.ts
function nearestPlaced(placed, index) {
  for (let offset = 1; offset < placed.length; offset++) {
    const before = placed[index - offset];
    const after = placed[index + offset];
    if (before) {
      return before;
    }
    if (after) {
      return after;
    }
  }
  return null;
}
__name(nearestPlaced, "nearestPlaced");
function closestTo(anchor, options) {
  return options.reduce((best, option) => distanceNm(anchor, option) < distanceNm(anchor, best) ? option : best);
}
__name(closestTo, "closestTo");
function namedIdents(route) {
  return route.map(classifyToken).flatMap((token) => token.kind === "named" ? [token.ident] : []);
}
__name(namedIdents, "namedIdents");
function placeFixes(route, candidates) {
  const waypoints = route.map(classifyToken).filter((token) => token.kind !== "airway");
  const placed = waypoints.map((waypoint) => {
    if (waypoint.kind === "point") {
      return waypoint.coordinates;
    }
    const options = waypoint.kind === "named" ? candidates.get(waypoint.ident) ?? [] : [];
    return options.length === 1 ? options[0] : null;
  });
  let progressed = true;
  while (progressed) {
    progressed = false;
    waypoints.forEach((waypoint, index) => {
      const options = waypoint.kind === "named" ? candidates.get(waypoint.ident) ?? [] : [];
      if (placed[index] || options.length < 2) {
        return;
      }
      const anchor = nearestPlaced(placed, index);
      if (anchor) {
        placed[index] = closestTo(anchor, options);
        progressed = true;
      }
    });
  }
  const fixes = [];
  const unresolvedFixes = [];
  waypoints.forEach((waypoint, index) => {
    const position = placed[index];
    if (position) {
      fixes.push({ ident: waypoint.ident, latitude: position.latitude, longitude: position.longitude });
    } else {
      unresolvedFixes.push(waypoint.ident);
    }
  });
  return { fixes, unresolvedFixes };
}
__name(placeFixes, "placeFixes");
function placeTrack(track, candidates) {
  const { fixes, unresolvedFixes } = placeFixes(track.route, candidates);
  return {
    system: track.system,
    identifier: track.identifier,
    direction: track.direction,
    issuingAuthority: track.issuingAuthority,
    notamNumber: track.notamNumber,
    validFrom: track.validFrom,
    validTo: track.validTo,
    route: track.route.join(" "),
    levels: [],
    fixes,
    unresolvedFixes,
    remarks: track.remarks,
    message: track.message
  };
}
__name(placeTrack, "placeTrack");

// src/domain/track.ts
function compareTracks(a, b) {
  return a.issuingAuthority.localeCompare(b.issuingAuthority) || a.identifier.localeCompare(b.identifier, "en", { numeric: true }) || a.validFrom.localeCompare(b.validFrom);
}
__name(compareTracks, "compareTracks");

// src/shared/logger.ts
var SEVERITY = {
  verbose: 10,
  debug: 20,
  log: 30,
  warn: 40,
  error: 50,
  fatal: 60
};
var DEFAULT_LEVEL = "log";
var PREFIX = "OceanicTracks";
var plain = /* @__PURE__ */ __name((text) => text, "plain");
function ansi(open) {
  return (text) => `\x1B[${open}m${text}\x1B[39m`;
}
__name(ansi, "ansi");
var COLORS = {
  verbose: ansi("96"),
  debug: ansi("95"),
  log: ansi("32"),
  warn: ansi("33"),
  error: ansi("31"),
  fatal: /* @__PURE__ */ __name((text) => `\x1B[1m${text}\x1B[0m`, "fatal")
};
var CONTEXT_COLOR = ansi("38;5;3");
function isLevel(value) {
  return value in SEVERITY;
}
__name(isLevel, "isLevel");
function threshold() {
  const configured = (process.env.LOG_LEVEL ?? "").toLowerCase();
  return SEVERITY[isLevel(configured) ? configured : DEFAULT_LEVEL];
}
__name(threshold, "threshold");
function colored() {
  return process.stdout.isTTY === true && !process.env.NO_COLOR;
}
__name(colored, "colored");
function timestamp() {
  return (/* @__PURE__ */ new Date()).toLocaleString("en-US", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "numeric",
    minute: "numeric",
    second: "numeric"
  });
}
__name(timestamp, "timestamp");
function format(level, context, message) {
  const paint = colored() ? COLORS[level] : plain;
  const contextPaint = colored() ? CONTEXT_COLOR : plain;
  const pid = paint(`[${PREFIX}] ${process.pid}  - `);
  const label = paint(level.toUpperCase().padStart(7, " "));
  return `${pid}${timestamp()} ${label} ${contextPaint(`[${context}] `)}${paint(message)}`;
}
__name(format, "format");
function write(level, context, message, stack) {
  if (SEVERITY[level] < threshold()) {
    return;
  }
  const stream = level === "error" || level === "fatal" ? process.stderr : process.stdout;
  stream.write(`${format(level, context, message)}
${stack ? `${stack}
` : ""}`);
}
__name(write, "write");
function describeError(error, depth = 3) {
  if (!(error instanceof Error)) {
    try {
      return `Non-error thrown: ${JSON.stringify(error)}`;
    } catch {
      return `Non-error thrown: ${String(error)}`;
    }
  }
  const head = `${error.name}: ${error.message}`;
  if (depth <= 1 || error.cause === void 0 || error.cause === null) {
    return head;
  }
  return `${head} (caused by: ${describeError(error.cause, depth - 1)})`;
}
__name(describeError, "describeError");
function stackOf(error) {
  return error instanceof Error ? error.stack : void 0;
}
__name(stackOf, "stackOf");
var Logger = class {
  constructor(context) {
    this.context = context;
  }
  context;
  static {
    __name(this, "Logger");
  }
  verbose(message) {
    write("verbose", this.context, message);
  }
  debug(message) {
    write("debug", this.context, message);
  }
  log(message) {
    write("log", this.context, message);
  }
  warn(message) {
    write("warn", this.context, message);
  }
  error(message, stack) {
    write("error", this.context, message, stack);
  }
  fatal(message, stack) {
    write("fatal", this.context, message, stack);
  }
};

// src/application/list-current-tracks.ts
var CACHE_TTL_MS = 3e5;
var ListCurrentTracks = class _ListCurrentTracks {
  constructor(pacots, fixDirectory) {
    this.pacots = pacots;
    this.fixDirectory = fixDirectory;
  }
  pacots;
  fixDirectory;
  static {
    __name(this, "ListCurrentTracks");
  }
  logger = new Logger(_ListCurrentTracks.name);
  cached = null;
  async execute() {
    if (this.cached && this.cached.expiresAt > Date.now()) {
      this.logger.debug("Serving the tracks from cache.");
      return this.cached.value;
    }
    const { tracks: published, unreadableMessages } = await this.pacots.load();
    const candidates = await this.fixDirectory.locate(published.flatMap((track) => namedIdents(track.route)));
    const tracks = published.map((track) => placeTrack(track, candidates)).sort(compareTracks);
    const value = { fetchedAt: (/* @__PURE__ */ new Date()).toISOString(), tracks, unreadableMessages };
    this.cached = { value, expiresAt: Date.now() + CACHE_TTL_MS };
    const unresolved = tracks.reduce((count, track) => count + track.unresolvedFixes.length, 0);
    this.logger.log(
      `Assembled ${tracks.length} tracks, ${unresolved} fixes unplaced, ${unreadableMessages.length} messages unreadable.`
    );
    return value;
  }
};

// src/domain/message/fukuoka.parser.ts
var TRACK_HEADER = /^TRACK\s+([A-Z0-9]+)\.?$/;
var LABELLED_LINE = /^((?:[A-Z0-9/]+\s)?ROUTE|RMK)\s*:\s*(.*)$/;
var TRACK_ROUTE = "FLEX ROUTE";
var REMARKS = "RMK";
function toTrack(draft) {
  const route = (draft.sections.get(TRACK_ROUTE) ?? []).join(" ").split(/\s+/).filter(Boolean);
  if (route.length === 0) {
    return null;
  }
  const remarks = (draft.sections.get(REMARKS) ?? []).filter(Boolean).join("\n");
  return { identifier: draft.identifier, route, remarks: remarks === "" ? null : remarks };
}
__name(toTrack, "toTrack");
function parseFukuokaMessage(text) {
  const drafts = [];
  for (const rawLine of text.split(/\r\n|\r|\n/)) {
    const line = rawLine.trim();
    if (line === "") {
      continue;
    }
    const header = TRACK_HEADER.exec(line);
    if (header) {
      drafts.push({ identifier: header[1], sections: /* @__PURE__ */ new Map(), label: null });
      continue;
    }
    const draft = drafts.at(-1);
    if (!draft) {
      continue;
    }
    const labelled = LABELLED_LINE.exec(line);
    const label = labelled ? labelled[1].replace(/\s+/g, " ") : draft.label;
    const content = labelled ? labelled[2].trim() : line;
    if (label === null) {
      continue;
    }
    draft.label = label;
    draft.sections.set(label, [...draft.sections.get(label) ?? [], content]);
  }
  const tracks = drafts.map(toTrack);
  return tracks.every((track) => track !== null) ? tracks : [];
}
__name(parseFukuokaMessage, "parseFukuokaMessage");

// src/domain/message/oakland.parser.ts
var HEADER = /^TDM TRK ([A-Z0-9]+) \d{12} \d{10} \d{10} (.+)$/;
var SECTION = /(?:^|\s)(RTS|RMK)\//;
function remarksOf(value) {
  const remarks = value?.trim() ?? "";
  return remarks === "" || remarks === "0" ? null : remarks;
}
__name(remarksOf, "remarksOf");
function parseOaklandMessage(text) {
  const message = text.replace(/\s+/g, " ").trim().replace(/^\(\s*/, "").replace(/\s*\)$/, "");
  const header = HEADER.exec(message);
  if (!header) {
    return [];
  }
  const [, identifier, body] = header;
  const firstSection = body.search(SECTION);
  const route = (firstSection === -1 ? body : body.slice(0, firstSection)).trim();
  const remarks = /(?:^|\s)RMK\/(.*)$/.exec(body)?.[1];
  if (route === "") {
    return [];
  }
  return [{ identifier, route: route.split(" "), remarks: remarksOf(remarks) }];
}
__name(parseOaklandMessage, "parseOaklandMessage");

// src/application/pacots-messages.ts
var CANCELLATION = "C";
var ISSUERS = [
  { location: "KZAK", keyword: "TDM TRK", direction: "west", parse: parseOaklandMessage },
  { location: "RJJJ", keyword: "PACOTS", direction: "east", parse: parseFukuokaMessage }
];
function isoInstant(value) {
  const instant = new Date(value);
  return Number.isNaN(instant.getTime()) ? null : instant.toISOString();
}
__name(isoInstant, "isoInstant");
var PacotsMessages = class _PacotsMessages {
  constructor(source) {
    this.source = source;
  }
  source;
  static {
    __name(this, "PacotsMessages");
  }
  logger = new Logger(_PacotsMessages.name);
  async load() {
    const tracks = [];
    const unreadableMessages = [];
    for (const issuer of ISSUERS) {
      const messages = await this.source.find(issuer.location, issuer.keyword);
      const seen = /* @__PURE__ */ new Set();
      for (const message of messages) {
        if (message.type === CANCELLATION || seen.has(message.number)) {
          continue;
        }
        seen.add(message.number);
        const parsed = issuer.parse(message.text);
        const validFrom = isoInstant(message.validFrom);
        const validTo = isoInstant(message.validTo);
        if (parsed.length === 0 || validFrom === null || validTo === null) {
          this.logger.warn(`Could not read ${issuer.location} track message ${message.number}.`);
          unreadableMessages.push(message.number);
          continue;
        }
        for (const track of parsed) {
          tracks.push({
            ...track,
            system: "pacots",
            direction: issuer.direction,
            issuingAuthority: issuer.location,
            notamNumber: message.number,
            validFrom,
            validTo,
            message: message.text
          });
        }
      }
    }
    return { tracks, unreadableMessages };
  }
};

// src/infra/http/fetch-with-retry.ts
var TIMEOUT_MS = 3e4;
var RETRIES = 1;
var BACKOFF_MS = 500;
var delay = /* @__PURE__ */ __name((ms) => new Promise((resolve) => setTimeout(resolve, ms)), "delay");
async function fetchWithRetry(url, init, logger4, unreachable) {
  const target = url.split("?")[0];
  for (let attempt = 0; attempt <= RETRIES; attempt++) {
    try {
      return await fetch(url, { ...init, signal: AbortSignal.timeout(TIMEOUT_MS) });
    } catch (error) {
      if (attempt === RETRIES) {
        logger4.error(`Could not reach ${target} in ${RETRIES + 1} attempts: ${describeError(error)}`);
        throw unreachable();
      }
      const backoff = BACKOFF_MS * 2 ** attempt;
      logger4.warn(
        `Attempt ${attempt + 1} to reach ${target} failed: ${describeError(error)}. Retrying in ${backoff}ms.`
      );
      await delay(backoff);
    }
  }
  throw unreachable();
}
__name(fetchWithRetry, "fetchWithRetry");

// src/infra/fix-directory/dms.ts
var DMS = /^(\d{1,3})-(\d{1,2})-(\d{1,2}(?:\.\d+)?)([NSEW])$/;
function round2(value) {
  return Math.round(value * 1e6) / 1e6;
}
__name(round2, "round");
function parseDms(value) {
  const match = DMS.exec(value.trim());
  if (!match) {
    return null;
  }
  const [, degrees, minutes, seconds, hemisphere] = match;
  const magnitude = Number(degrees) + Number(minutes) / 60 + Number(seconds) / 3600;
  const limit = hemisphere === "N" || hemisphere === "S" ? 90 : 180;
  if (magnitude > limit || Number(minutes) >= 60 || Number(seconds) >= 60) {
    return null;
  }
  return round2(hemisphere === "S" || hemisphere === "W" ? -magnitude : magnitude);
}
__name(parseDms, "parseDms");

// src/infra/fix-directory/fix-directory.client.ts
var CACHE_TTL_MS2 = 864e5;
var IDENTS_PER_QUERY = 100;
var SAME_FIX_WITHIN_NM = 5;
var IDENT = /^[A-Z0-9]{2,5}$/;
var LAYERS = [
  { service: "DesignatedPoints", ident: "IDENT", latitude: "LATITUDE", longitude: "LONGITUDE" },
  { service: "NavaidComponents", ident: "IDENT", latitude: "LATITUDE", longitude: "LONGITUDE" },
  { service: "DesignatedPoint", ident: "IDENT_TXT", latitude: "LAT_TXT", longitude: "LONG_TXT" }
];
var FixDirectoryClient = class _FixDirectoryClient {
  constructor(options) {
    this.options = options;
    this.host = options.host.replace(/\/+$/, "");
  }
  options;
  static {
    __name(this, "FixDirectoryClient");
  }
  logger = new Logger(_FixDirectoryClient.name);
  host;
  cache = /* @__PURE__ */ new Map();
  async locate(idents) {
    const wanted = [...new Set(idents)].filter((ident) => IDENT.test(ident));
    const missing = wanted.filter((ident) => (this.cache.get(ident)?.expiresAt ?? 0) <= Date.now());
    if (missing.length > 0) {
      const found = new Map(missing.map((ident) => [ident, []]));
      for (const layer of LAYERS) {
        for (const [ident, position] of await this.query(layer, missing)) {
          const known = found.get(ident) ?? [];
          if (!known.some((candidate) => distanceNm(candidate, position) < SAME_FIX_WITHIN_NM)) {
            found.set(ident, [...known, position]);
          }
        }
      }
      const expiresAt = Date.now() + CACHE_TTL_MS2;
      found.forEach((candidates, ident) => {
        this.cache.set(ident, { candidates, expiresAt });
      });
      this.logger.debug(
        `Looked up ${missing.length} fixes, placed ${[...found.values()].filter((c) => c.length).length}.`
      );
    }
    return new Map(wanted.map((ident) => [ident, this.cache.get(ident)?.candidates ?? []]));
  }
  async query(layer, idents) {
    const positions = [];
    for (let start = 0; start < idents.length; start += IDENTS_PER_QUERY) {
      const batch = idents.slice(start, start + IDENTS_PER_QUERY);
      const query = new URLSearchParams({
        where: `${layer.ident} IN (${batch.map((ident) => `'${ident}'`).join(",")})`,
        outFields: [layer.ident, layer.latitude, layer.longitude].join(","),
        returnGeometry: "false",
        f: "json"
      });
      const response = await fetchWithRetry(
        `${this.host}/${layer.service}/FeatureServer/0/query?${query}`,
        { headers: { Accept: "application/json", "User-Agent": this.options.userAgent } },
        this.logger,
        () => new FixDirectoryUnavailableError()
      );
      const body = await response.json().catch(() => null);
      if (!response.ok || body === null || body.error !== void 0 || !Array.isArray(body.features)) {
        this.logger.warn(`The fix directory layer ${layer.service} answered ${response.status} without features.`);
        throw new FixDirectoryUnavailableError();
      }
      for (const feature of body.features) {
        const attributes = feature.attributes ?? {};
        const ident = attributes[layer.ident];
        const latitude = parseDms(String(attributes[layer.latitude] ?? ""));
        const longitude = parseDms(String(attributes[layer.longitude] ?? ""));
        if (typeof ident === "string" && batch.includes(ident) && latitude !== null && longitude !== null) {
          positions.push([ident, { latitude, longitude }]);
        }
      }
    }
    return positions;
  }
};

// src/infra/http/handler.ts
var ERROR_RESPONSES = [
  {
    error: TrackSourceUnavailableError,
    status: 502,
    code: "NMS_UNAVAILABLE",
    message: "The FAA NOTAM service is unavailable."
  },
  {
    error: FixDirectoryUnavailableError,
    status: 502,
    code: "FIX_DIRECTORY_UNAVAILABLE",
    message: "The FAA fix directory is unavailable."
  },
  {
    error: TrackSourceNotConfiguredError,
    status: 500,
    code: "NMS_NOT_CONFIGURED",
    message: "The FAA NOTAM service credentials are not configured."
  }
];
var logger = new Logger("TracksHandler");
function errorBody(status, code, message) {
  return { statusCode: status, body: { error: { code, message, status } } };
}
__name(errorBody, "errorBody");
async function handleRequest(resolveUseCase2) {
  const startedAt = Date.now();
  try {
    const tracks = await resolveUseCase2().execute();
    logger.log(`Served ${tracks.tracks.length} tracks in ${Date.now() - startedAt}ms.`);
    return { statusCode: 200, body: tracks };
  } catch (error) {
    const known = ERROR_RESPONSES.find((response) => error instanceof response.error);
    if (known) {
      logger.warn(`Track lookup failed after ${Date.now() - startedAt}ms with ${known.status} ${known.code}.`);
      return errorBody(known.status, known.code, known.message);
    }
    logger.error(`Track lookup crashed after ${Date.now() - startedAt}ms: ${describeError(error)}`, stackOf(error));
    return errorBody(500, "INTERNAL_ERROR", "Oceanic track lookup failed.");
  }
}
__name(handleRequest, "handleRequest");

// src/infra/nms/nms.client.ts
var REQUEST_SPACING_MS = 1100;
var TOKEN_RENEWAL_MARGIN_MS = 6e4;
var DEFAULT_TOKEN_LIFETIME_S = 1799;
var NmsClient = class _NmsClient {
  constructor(options) {
    this.options = options;
    this.host = options.host.replace(/\/+$/, "");
  }
  options;
  static {
    __name(this, "NmsClient");
  }
  logger = new Logger(_NmsClient.name);
  host;
  token = null;
  lastRequestAt = 0;
  async find(location, keyword) {
    const query = new URLSearchParams({ location, freeText: keyword }).toString();
    const url = `${this.host}/nmsapi/v1/notams?${query}`;
    let response = await this.requestNotams(url, await this.accessToken());
    if (response.status === 401) {
      this.logger.warn(`The NOTAM service refused the access token for ${location}. Renewing it once.`);
      this.token = null;
      response = await this.requestNotams(url, await this.accessToken());
    }
    const body = await response.json().catch(() => null);
    if (response.status === 400 && body?.errors?.some((error) => error.message?.startsWith("No data found"))) {
      return [];
    }
    if (!response.ok || body === null) {
      const reason = response.status === 429 ? "rate limited the request" : `answered ${response.status}`;
      this.logger.warn(`The NOTAM service ${reason} for ${location}.`);
      throw new TrackSourceUnavailableError();
    }
    const notams = (body.data?.geojson ?? []).flatMap((feature) => {
      const notam = feature.properties?.coreNOTAMData?.notam;
      if (!notam?.number || !notam.text || !notam.effectiveStart || !notam.effectiveEnd) {
        return [];
      }
      return [
        {
          number: notam.number,
          type: notam.type ?? "N",
          validFrom: notam.effectiveStart,
          validTo: notam.effectiveEnd,
          text: notam.text
        }
      ];
    });
    this.logger.debug(`Read ${notams.length} NOTAMs for ${location} matching "${keyword}".`);
    return notams;
  }
  async requestNotams(url, accessToken) {
    await delay(Math.max(0, this.lastRequestAt + REQUEST_SPACING_MS - Date.now()));
    this.lastRequestAt = Date.now();
    return fetchWithRetry(
      url,
      {
        headers: {
          Accept: "application/json",
          Authorization: `Bearer ${accessToken}`,
          nmsResponseFormat: "GEOJSON",
          "User-Agent": this.options.userAgent
        }
      },
      this.logger,
      () => new TrackSourceUnavailableError()
    );
  }
  async accessToken() {
    if (this.token && this.token.expiresAt > Date.now()) {
      return this.token.value;
    }
    const credentials = Buffer.from(`${this.options.clientId}:${this.options.clientSecret}`).toString("base64");
    const response = await fetchWithRetry(
      `${this.host}/v1/auth/token`,
      {
        method: "POST",
        headers: {
          Accept: "application/json",
          Authorization: `Basic ${credentials}`,
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": this.options.userAgent
        },
        body: "grant_type=client_credentials"
      },
      this.logger,
      () => new TrackSourceUnavailableError()
    );
    const body = await response.json().catch((error) => {
      this.logger.warn(`Could not read the token response: ${describeError(error)}`);
      return null;
    });
    if (!response.ok || !body?.access_token) {
      this.logger.warn(`The NOTAM service refused a token with ${response.status} ${body?.ErrorCode ?? "unknown"}.`);
      throw new TrackSourceUnavailableError();
    }
    const lifetimeS = Number(body.expires_in ?? DEFAULT_TOKEN_LIFETIME_S);
    const lifetimeMs = (Number.isFinite(lifetimeS) ? lifetimeS : DEFAULT_TOKEN_LIFETIME_S) * 1e3;
    this.token = {
      value: body.access_token,
      expiresAt: Date.now() + Math.max(0, lifetimeMs - TOKEN_RENEWAL_MARGIN_MS)
    };
    return this.token.value;
  }
};

// src/function.ts
var DEFAULT_NMS_HOST = "https://api-nms.aim.faa.gov";
var DEFAULT_FIX_DIRECTORY_HOST = "https://services6.arcgis.com/ssFJjBXIUyZDrSYZ/arcgis/rest/services";
var DEFAULT_USER_AGENT = "MyPreflight/1.0 (+https://mypreflight.io)";
var logger2 = new Logger("TracksFunction");
var useCase;
function resolveUseCase() {
  if (!useCase) {
    const clientId = process.env.NMS_CLIENT_ID;
    const clientSecret = process.env.NMS_CLIENT_SECRET;
    if (!clientId || !clientSecret) {
      throw new TrackSourceNotConfiguredError();
    }
    const nmsHost = process.env.NMS_API_HOST || DEFAULT_NMS_HOST;
    const fixDirectoryHost = process.env.FIX_DIRECTORY_HOST || DEFAULT_FIX_DIRECTORY_HOST;
    const userAgent = process.env.OCEANIC_TRACKS_USER_AGENT || DEFAULT_USER_AGENT;
    useCase = new ListCurrentTracks(
      new PacotsMessages(new NmsClient({ host: nmsHost, clientId, clientSecret, userAgent })),
      new FixDirectoryClient({ host: fixDirectoryHost, userAgent })
    );
    logger2.log(`Cold start. Reading NOTAMs from ${nmsHost} and fixes from ${fixDirectoryHost}.`);
  }
  return useCase;
}
__name(resolveUseCase, "resolveUseCase");
async function main() {
  const { statusCode, body } = await handleRequest(resolveUseCase);
  return {
    statusCode,
    headers: { "Content-Type": "application/json" },
    body
  };
}
__name(main, "main");

// src/lambda.ts
var ROUTE = "/tracks";
var SECRET_HEADER = "x-require-whisk-auth";
var logger3 = new Logger("TracksLambda");
var invoke = main;
function errorResponse(status, code, message) {
  return {
    statusCode: status,
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ error: { code, message, status } })
  };
}
__name(errorResponse, "errorResponse");
function authorised(provided) {
  const secret = process.env.OCEANIC_TRACKS_FUNCTION_SECRET;
  if (!secret) {
    logger3.warn("Refused a request: OCEANIC_TRACKS_FUNCTION_SECRET is not set.");
    return false;
  }
  if (provided === void 0) {
    return false;
  }
  const expected = Buffer.from(secret);
  const actual = Buffer.from(provided);
  return expected.length === actual.length && (0, import_node_crypto.timingSafeEqual)(expected, actual);
}
__name(authorised, "authorised");
async function handler(event) {
  if (!authorised(event.headers?.[SECRET_HEADER])) {
    return errorResponse(401, "UNAUTHORIZED", "The X-Require-Whisk-Auth header is missing or wrong.");
  }
  if (event.rawPath !== ROUTE) {
    return errorResponse(404, "NOT_FOUND", `The function answers on ${ROUTE} only.`);
  }
  const args = {
    ...event.queryStringParameters,
    __ow_method: event.requestContext.http.method.toLowerCase()
  };
  const { statusCode, headers, body } = await invoke(args);
  return { statusCode, headers, body: typeof body === "string" ? body : JSON.stringify(body) };
}
__name(handler, "handler");
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
